# Source Code

This folder contains the various source codes required to run the Pallid Sturgeon population model. 

# Some notes regarding population structure and life history
<<<<<<< HEAD
* Most North American sturgeons spawn between the spring equinox and summer solstice, with a spawning run peak often coinciding with annual peak flow (Cech and Doroshov, 2004). 

# THINGS TO DO
1. NEED TO BUILD IN EMBRYO TO AGE-0 DYNAMICS FOR HATCHERY AND NATURAL FISH
2. LINK STOCKING FOR HATCHERY FISH
3. MAKE FUNCTION TO STOCHASTICALLY SIM REPLICATES FOR ANALYSIS
=======
* Most North American sturgeons spawn between the spring equinox and summer solstice, with a spawning run peak often coinciding with annual peak flow (Cech and Doroshov, 2004). 
>>>>>>> origin/master
