
	setwd("C:/Users/mcolvin/Documents/projects/Pallid Sturgeon/Analysis/Model/")
	source("./src/01_global.R")
	source("./src/02_load.R")
	source("./src/03_functions.R")
	source("./src/04_tables.R")
	source("./src/05_figures.R")
	
	#source("./src/06_run.R")
	source("./src/07_analysis.R")
	source("./src/08_main.R")









