library(triangle)
library(reshape2)
library(plyr)
library(lattice)