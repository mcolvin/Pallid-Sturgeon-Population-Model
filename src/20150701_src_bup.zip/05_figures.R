figures<- function(n)
	{
	if(n==1)
		{
		trans_grey<- rgb(120,120,120,alpha=10,maxColorValue=255)
	plot(total~year,out, xlab="Year",
		ylab="Population (natural and hatchery produced)",type='n')
	for(x in 1:max(out$rep)) 
		{points(total~year,out,subset=rep==x,col=trans_grey,type='l',
			lwd=2)}
	panLab(paste("Psuedo-extinction probability:", 
		round(
			(nrow(out[out$year==50& out$total < 50,]))/max(out$rep),
				2)))

}
	if(n==2)
		{
		matplot(c(2:100),vals[,-1],type='l',xlab="Year",ylab="Lambda")
		}	
	if(n==3)
		{
		xyplot(total~year,out, group=rep,type='l',xlab="Year",ylab="Population (hatural and hatchery produced)")
		}	
	if(n==4)
		{
		matplot(c(2:100),vals[,-1],type='l',xlab="Year",ylab="Lambda")
		}	
	if(n==5)
		{
		boxplot(mn_lambda~scenario, g_mn,ylab="Lambda (geometric mean)")
		}	
	if(n==6)
		{
		par(mar=c(4,15,1,1))
		plot(c(min(tornado$mns),max(tornado$mxs)),c(1,14),type="n",las=1,xlab="Expected population size",
			yaxt="n",ylab="")
		axis(2, at=c(1:14),labels=tornado$parms,las=1)
		segments(tornado$mns,tornado$y,tornado$mxs,tornado$y,lwd=4)
		}	
	if(n==7){par(mar=c(4,15,1,1))
		plot(c(500,3000),c(1,14),type="n",las=1,xlab="Expected population size",
			yaxt="n",ylab="")
		axis(2, at=c(1:14),labels=tornado$parms,las=1)
		segments(tornado$mns,tornado$y,tornado$mxs,tornado$y,lwd=4)
		}
	if(n==8){par(mar=c(4,15,1,1))
		plot(c(0,65000),c(1,14),type="n",las=1,xlab="Expected population size",
			yaxt="n",ylab="")
		axis(2, at=c(1:14),labels=tornado$parms,las=1)
		segments(tornado$mns,tornado$y,tornado$mxs,tornado$y,lwd=4)
		}
	if(n==9){par(mar=c(4,15,1,1))
		plot(c(0,2000),c(1,14),type="n",las=1,xlab="Expected population size",
			yaxt="n",ylab="")
		axis(2, at=c(1:14),labels=tornado$parms,las=1)
		segments(tornado$mns,tornado$y,tornado$mxs,tornado$y,lwd=4)
		}
	if(n==10){}
	if(n==11){}
	if(n==12){}
	if(n==13){}
	if(n==14){}
	}